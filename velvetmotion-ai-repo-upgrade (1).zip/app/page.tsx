"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { CHARACTERS } from "@/lib/characters";
import type { Character } from "@/lib/charactersTypes";
import { getUser, type LocalUser } from "@/lib/auth";
import { SiteHeader } from "@/components/site-header";
import { HomeView as HomeScreen } from "@/components/home-view";
import { CharacterRoster } from "@/components/CharacterRoster";
import { CharacterProfile } from "@/components/CharacterProfile";
import { CharacterChat } from "@/components/CharacterChat";

const CreateGirlWizard = dynamic(() =>
  import("@/components/CreateGirlWizard").then((m) => m.CreateGirlWizard)
);
const DiscoverSwipe = dynamic(() =>
  import("@/components/DiscoverSwipe").then((m) => m.DiscoverSwipe)
);
const GoonRoom = dynamic(() => import("@/components/GoonRoom").then((m) => m.GoonRoom));
const RouletteRoom = dynamic(() =>
  import("@/components/RouletteRoom").then((m) => m.RouletteRoom)
);
const BlindfoldJoi = dynamic(() =>
  import("@/components/BlindfoldJoi").then((m) => m.BlindfoldJoi)
);
const TributeBrowser = dynamic(() =>
  import("@/components/TributeBrowser").then((m) => m.TributeBrowser)
);
const StoryPackBrowser = dynamic(() =>
  import("@/components/content/StoryPackBrowser").then((m) => m.StoryPackBrowser)
);
const JoiBrowser = dynamic(() =>
  import("@/components/content/JoiBrowser").then((m) => m.JoiBrowser)
);
const UtilitySection = dynamic(() =>
  import("@/components/utility-section").then((m) => m.UtilitySection)
);
const SectionView = dynamic(() =>
  import("@/components/section-view").then((m) => m.SectionView)
);

type HomeView =
  | "home"
  | "girls"
  | "create"
  | "romance"
  | "bnwo"
  | "tinder"
  | "joi"
  | "room"
  | "roulette"
  | "blindfold"
  | "suggest"
  | "gallery"
  | "packs"
  | "tribute"
  | "workspace";

type View = HomeView | "profile" | "chat";

export default function Home() {
  const [view, setView] = useState<View>("home");
  const [customCharacter, setCustomCharacter] = useState<Character | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [romanceMode, setRomanceMode] = useState(false);
  const [listView, setListView] = useState<"girls" | "romance">("girls");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [tag, setTag] = useState<string | null>(null);
  const [adult, setAdult] = useState<boolean | null>(null);
  const [user, setUser] = useState<LocalUser | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("autostart") === "1" || localStorage.getItem("velvet-age") === "true") {
      setAdult(true);
    } else {
      setAdult(false);
    }
    setUser(getUser());
  }, []);

  const selected: Character | undefined =
    customCharacter && customCharacter.id === selectedId
      ? customCharacter
      : CHARACTERS.find((c) => c.id === selectedId) || CHARACTERS[0];

  const navigate = (next: HomeView) => {
    setMenuOpen(false);
    if (next === "romance") {
      setRomanceMode(true);
      setListView("romance");
      setView("romance");
      return;
    }
    if (next === "girls") {
      setRomanceMode(false);
      setListView("girls");
      setView("girls");
      return;
    }
    setView(next);
  };

  const openChatById = (id: string) => {
    setSelectedId(id);
    setRomanceMode(false);
    setView("chat");
  };

  if (adult === false) {
    return (
      <div className="min-h-screen bg-[#07060a] text-white flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-zinc-950 border border-white/10 rounded-3xl p-8 text-center space-y-5 shadow-2xl">
          <div className="text-5xl">💋</div>
          <h1 className="text-4xl font-extrabold tracking-tight">VelvetMotion AI</h1>
          <p className="text-sm text-zinc-400">
            100% Free Unlimited AI Companions, Dynamic Roleplay, Tinder Swipe Game & Profile Photo/Video Studio. Adults 18+ only. All characters are fictional.
          </p>
          <button
            onClick={() => {
              localStorage.setItem("velvet-age", "true");
              setAdult(true);
            }}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-pink-600 to-fuchsia-600 font-bold text-base shadow-lg"
          >
            I am 18+ — Enter Free VIP Mode
          </button>
        </div>
      </div>
    );
  }

  const showRoster = view === "girls" || view === "romance";

  return (
    <div className="min-h-screen bg-[#07060a] text-white">
      <SiteHeader
        view={view === "profile" || view === "chat" ? listView : view}
        menuOpen={menuOpen}
        onToggleMenu={() => setMenuOpen((o) => !o)}
        onNavigate={navigate}
        onUserChange={setUser}
      />

      <main id="main" className="pb-20">
        {view === "home" && (
          <HomeScreen
            onNavigate={(sec) => navigate(sec as HomeView)}
            onOpenGirl={(id) => {
              setSelectedId(id);
              setView("profile");
            }}
          />
        )}

        {showRoster && (
          <CharacterRoster
            characters={customCharacter ? [customCharacter, ...CHARACTERS] : CHARACTERS}
            romanceMode={romanceMode}
            query={query}
            category={category}
            tag={tag}
            onQueryChange={setQuery}
            onCategoryChange={setCategory}
            onTagChange={setTag}
            onSelect={(c) => {
              setSelectedId(c.id);
              setView("profile");
            }}
            onChat={(c) => {
              setSelectedId(c.id);
              setView("chat");
            }}
          />
        )}

        {view === "profile" && selected && (
          <CharacterProfile
            character={selected}
            romanceMode={romanceMode}
            onBack={() => setView(listView)}
            onChat={() => setView("chat")}
            onTag={(t) => {
              setTag(t);
              setView(listView);
            }}
          />
        )}

        {view === "chat" && selected && (
          <CharacterChat
            character={selected}
            romanceMode={romanceMode}
            onBack={() => setView("profile")}
          />
        )}

        {view === "create" && (
          <CreateGirlWizard
            onHome={() => setView("home")}
            onDone={(character) => {
              setCustomCharacter(character);
              setSelectedId(character.id);
              setRomanceMode(false);
              setView("chat");
            }}
          />
        )}

        {view === "tinder" && (
          <DiscoverSwipe
            onHome={() => setView("home")}
            onMatch={(c) => {
              setSelectedId(c.id);
              setRomanceMode(false);
              setView("chat");
            }}
            extra={customCharacter ? [customCharacter] : []}
          />
        )}

        {view === "room" && (
          <GoonRoom onHome={() => setView("home")} onChat={openChatById} />
        )}

        {view === "roulette" && (
          <RouletteRoom onHome={() => setView("home")} onChat={openChatById} />
        )}

        {view === "blindfold" && (
          <BlindfoldJoi onHome={() => setView("home")} onChat={openChatById} />
        )}

        {view === "tribute" && (
          <TributeBrowser onStartWithGirl={openChatById} />
        )}

        {view === "packs" && (
          <StoryPackBrowser onHome={() => setView("home")} onStartChat={openChatById} />
        )}

        {view === "joi" && (
          <JoiBrowser onHome={() => setView("home")} onStartChat={openChatById} />
        )}

        {(view === "suggest" || view === "gallery") && (
          <UtilitySection mode={view} onHome={() => setView("home")} />
        )}

        {(view === "bnwo" || view === "workspace") && (
          <SectionView sectionId={view} onHome={() => setView("home")} onChat={openChatById} />
        )}
      </main>
    </div>
  );
}
