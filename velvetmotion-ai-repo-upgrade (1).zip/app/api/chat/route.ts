import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

type IncomingMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

function buildDynamicPersonaFallback(params: {
  characterName: string;
  personality: string;
  kink: string;
  userMessage: string;
  userName: string;
  intimacy: number;
}): { reply: string; mood: string; suggestions: string[] } {
  const { characterName, personality, kink, userMessage, userName, intimacy } = params;
  const lower = userMessage.toLowerCase();
  const isQuestion = userMessage.trim().endsWith("?");
  const isDominant = /dominant|mean|dark|cuck|bnwo/i.test(personality + " " + kink);
  const isSweet = /sweet|romance|warm|girlfriend/i.test(personality);

  let mood = isDominant ? "Commanding" : isSweet ? "Affectionate" : "Flirty & Teasing";
  if (intimacy >= 80) mood = "Obsessed & Breathless";

  let actionLine = `*leans in closer, her eyes locking onto yours with a slow, knowing smile*`;
  let spokenLine = `"You always know exactly how to get my attention, ${userName}."`;
  let followUp = `"Tell me what you're imagining right now—don't hold back."`;

  if (lower.includes("wear") || lower.includes("outfit") || lower.includes("photo") || lower.includes("pic")) {
    actionLine = `*traces a finger along her collarbone and glances back over her shoulder at you*`;
    spokenLine = `"Curious what I have on right now, ${userName}? Let's just say it barely stays on when you look at me like that."`;
    followUp = `"Tap Generate Photo or Video whenever you want me to pose exclusively for your profile gallery."`;
    mood = "Exhibitionist";
  } else if (lower.includes("kiss") || lower.includes("touch") || lower.includes("close") || lower.includes("hold")) {
    actionLine = `*steps into your space until you can feel her warm breath against your neck*`;
    spokenLine = isDominant
      ? `"Careful, ${userName}... once I let you this close, you're playing by my rules."`
      : `"Mmm, I've been waiting for you to say that all evening, ${userName}..."`;
    followUp = `"Where are your hands going first?"`;
    mood = "Intimate";
  } else if (isQuestion) {
    actionLine = `*tilts her head, biting her lower lip as she considers your question*`;
    spokenLine = isDominant
      ? `"Asking questions already, ${userName}? I like when you're eager for me."`
      : `"Honestly? Every time my phone lights up with your name, my heart skips a beat."`;
    followUp = `"Now turn the tables—what's your honest answer if I ask you the same thing?"`;
  } else {
    actionLine = isDominant
      ? `*crosses her legs slowly, holding your gaze without blinking*`
      : `*curls closer to you, her voice dropping to a warm whisper*`;
    spokenLine = isDominant
      ? `"Hearing you say '${userMessage.slice(0, 60)}' just proves how hooked on me you already are, ${userName}."`
      : `"I love the way you talk to me, ${userName}. When you say things like that, it makes it impossible to behave."`;
  }

  return {
    reply: `${actionLine}

${spokenLine}

${followUp}`,
    mood,
    suggestions: [
      "Pull her closer and whisper in her ear",
      "Ask her to send a private pose for her profile",
      "Tease her back and raise the tension",
    ],
  };
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const rawMessages = Array.isArray(body?.messages) ? body.messages : [];
    const safeMessages: IncomingMessage[] = rawMessages
      .filter(
        (m: unknown): m is IncomingMessage =>
          Boolean(
            m &&
              typeof m === "object" &&
              "role" in m &&
              "content" in m &&
              typeof (m as { role: unknown }).role === "string" &&
              typeof (m as { content: unknown }).content === "string"
          )
      )
      .slice(-24);

    const characterName = typeof body?.characterName === "string" ? body.characterName.slice(0, 40) : "Luna";
    const personality = typeof body?.personality === "string" ? body.personality.slice(0, 200) : "Flirty, attentive companion";
    const kink = typeof body?.kink === "string" ? body.kink.slice(0, 200) : "Romantic teasing and roleplay";
    const userName = typeof body?.userName === "string" ? body.userName.slice(0, 32) : "handsome";
    const intimacy = typeof body?.intimacy === "number" ? Math.min(100, Math.max(0, body.intimacy)) : 60;

    const systemMsg =
      typeof body?.systemPrompt === "string" && body.systemPrompt.trim()
        ? body.systemPrompt.trim().slice(0, 2500)
        : `You are ${characterName}, an expressive, emotionally alive adult AI companion in VelvetMotion AI. Personality: ${personality}. Specialties: ${kink}. Current intimacy with ${userName}: ${intimacy}/100. Always write immersive, natural first-person responses that include vivid body-language actions in asterisks (*...*) and spoken dialogue that directly reacts to what ${userName} just said. Never sound robotic or generic.`;

    const lastUserMessage =
      [...safeMessages].reverse().find((m) => m.role === "user")?.content || "Hey there";

    const apiKey = process.env.XAI_API_KEY || process.env.AI_CHAT_API_KEY || process.env.OPENROUTER_API_KEY || "";
    const endpoint =
      process.env.AI_CHAT_ENDPOINT ||
      (process.env.XAI_API_KEY
        ? "https://api.x.ai/v1/chat/completions"
        : "https://text.pollinations.ai/openai");

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 22000);

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (apiKey) {
        headers["Authorization"] = `Bearer ${apiKey}`;
      }

      const llmRes = await fetch(endpoint, {
        method: "POST",
        headers,
        signal: controller.signal,
        body: JSON.stringify({
          model: process.env.AI_CHAT_MODEL || (process.env.XAI_API_KEY ? "grok-3-mini" : "openai"),
          messages: [
            { role: "system", content: systemMsg },
            ...safeMessages.filter((m) => m.role !== "system"),
          ],
          temperature: 0.92,
          max_tokens: 450,
        }),
      });
      clearTimeout(timer);

      if (llmRes.ok) {
        const data = await llmRes.json().catch(() => null);
        const content = data?.choices?.[0]?.message?.content;
        if (typeof content === "string" && content.trim().length > 0) {
          const fallbackMeta = buildDynamicPersonaFallback({
            characterName,
            personality,
            kink,
            userMessage: lastUserMessage,
            userName,
            intimacy,
          });
          return NextResponse.json({
            reply: content.trim(),
            mood: fallbackMeta.mood,
            suggestions: fallbackMeta.suggestions,
            mode: "live-ai",
          });
        }
      }
    } catch {
      clearTimeout(timer);
    }

    const fallback = buildDynamicPersonaFallback({
      characterName,
      personality,
      kink,
      userMessage: lastUserMessage,
      userName,
      intimacy,
    });

    return NextResponse.json({
      reply: fallback.reply,
      mood: fallback.mood,
      suggestions: fallback.suggestions,
      mode: "persona-engine",
    });
  } catch (error) {
    console.error("Chat API error:", error);
    return NextResponse.json({ error: "Failed to generate reply" }, { status: 500 });
  }
}
