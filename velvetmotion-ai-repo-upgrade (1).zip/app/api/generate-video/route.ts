import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

const ALLOWED_ASPECT_RATIOS = new Set(["9:16", "16:9", "1:1", "3:4", "4:3"]);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const characterName = typeof body?.characterName === "string" ? body.characterName.slice(0, 40) : "Luna";
    const appearance =
      typeof body?.appearance === "string"
        ? body.appearance.slice(0, 220)
        : "glamorous adult woman, cinematic lighting, expressive gaze";
    const pose = typeof body?.pose === "string" ? body.pose.slice(0, 120) : "slow seductive turn toward camera";
    const aspectRatio = ALLOWED_ASPECT_RATIOS.has(body?.aspectRatio) ? body.aspectRatio : "9:16";

    const baseSeed = Math.floor(Math.random() * 800000) + 100000;
    const motionBeats = [
      "subtle warm smile, eye contact, soft neon key light",
      "leaning closer to camera, playful expression, hair movement",
      "over-the-shoulder glance, intimate luxury lounge ambiance",
      "blowing a soft kiss toward viewer, shallow depth of field",
    ];

    const frames = motionBeats.map((beat, idx) => {
      const framePrompt = `8k photorealistic cinematic motion frame ${idx + 1} of ${characterName}, ${appearance}, ${pose}, ${beat}, high fashion editorial`;
      return `https://image.pollinations.ai/prompt/${encodeURIComponent(
        framePrompt
      )}?width=720&height=1080&seed=${baseSeed + idx}&model=flux&nologo=true`;
    });

    const videoEndpoint = process.env.AI_VIDEO_ENDPOINT;
    if (videoEndpoint) {
      try {
        const res = await fetch(videoEndpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(process.env.AI_VIDEO_API_KEY
              ? { Authorization: `Bearer ${process.env.AI_VIDEO_API_KEY}` }
              : {}),
          },
          body: JSON.stringify({
            prompt: `${characterName}, ${appearance}, ${pose}`,
            aspectRatio,
          }),
        });
        if (res.ok) {
          const data = await res.json().catch(() => null);
          if (typeof data?.videoUrl === "string" && data.videoUrl) {
            return NextResponse.json({
              url: data.videoUrl,
              frames,
              type: "video",
              fallback: false,
              free: true,
              prompt: `${characterName} — ${pose}`,
            });
          }
        }
      } catch {
        // Fall through to multi-frame motion loop
      }
    }

    return NextResponse.json({
      url: frames[0],
      frames,
      type: "motion-loop",
      fallback: true,
      free: true,
      aspectRatio,
      prompt: `${characterName} — ${pose}`,
    });
  } catch (error) {
    console.error("Generate video error:", error);
    return NextResponse.json({ error: "Failed to generate video" }, { status: 500 });
  }
}
