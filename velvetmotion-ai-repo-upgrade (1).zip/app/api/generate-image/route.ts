import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const characterName = typeof body?.characterName === "string" ? body.characterName.slice(0, 40) : "Luna";
    const appearance =
      typeof body?.appearance === "string"
        ? body.appearance.slice(0, 220)
        : "glamorous adult model, expressive eyes, soft cinematic neon lighting";
    const pose = typeof body?.pose === "string" ? body.pose.slice(0, 120) : "confident over-the-shoulder portrait";
    const style = typeof body?.type === "string" ? body.type.slice(0, 40) : "portrait";
    const extra = typeof body?.extra === "string" ? body.extra.slice(0, 160) : "";
    const dual = typeof body?.dual === "string" ? body.dual.slice(0, 80) : "";

    const styleDescriptor =
      style === "lingerie"
        ? "luxury silk lace loungewear, moody bedroom lighting, editorial fashion photography"
        : style === "nude" || style === "explicit"
        ? "artistic boudoir silhouette, warm golden rim light, luxury suite aesthetic, high fashion"
        : "glamorous close-up portrait, luxury velvet lounge background, shallow depth of field";

    const fullPrompt = [
      `8k photorealistic editorial portrait of ${characterName}`,
      appearance,
      styleDescriptor,
      `pose: ${pose}`,
      dual ? `with companion ${dual} in frame` : "",
      extra,
      "cinematic lighting, sharp focus, masterpiece",
    ]
      .filter(Boolean)
      .join(", ");

    const seed = Math.floor(Math.random() * 900000) + 100000;
    const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      fullPrompt
    )}?width=768&height=1024&seed=${seed}&model=flux&nologo=true&enhance=true`;

    const customEndpoint = process.env.AI_IMAGE_ENDPOINT;
    if (customEndpoint) {
      try {
        const res = await fetch(customEndpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(process.env.AI_IMAGE_API_KEY
              ? { Authorization: `Bearer ${process.env.AI_IMAGE_API_KEY}` }
              : {}),
          },
          body: JSON.stringify({ prompt: fullPrompt, seed, width: 768, height: 1024 }),
        });
        if (res.ok) {
          const contentType = res.headers.get("content-type") || "";
          if (contentType.includes("application/json")) {
            const data = await res.json();
            if (typeof data?.url === "string" && data.url) {
              return NextResponse.json({
                url: data.url,
                prompt: fullPrompt,
                fallback: false,
                free: true,
              });
            }
          }
        }
      } catch {
        // Fall through to Pollinations Flux URL
      }
    }

    return NextResponse.json({
      url: pollinationsUrl,
      prompt: fullPrompt,
      fallback: Boolean(customEndpoint),
      free: true,
    });
  } catch (error) {
    console.error("Generate image error:", error);
    return NextResponse.json({ error: "Failed to generate image" }, { status: 500 });
  }
}
