export type GalleryItem = {
  id: string;
  characterId: string;
  characterName: string;
  type: string;
  url: string;
  frames?: string[];
  prompt?: string;
  createdAt: number;
};

export type StoredMessage = {
  role: "user" | "assistant";
  content: string;
  imageUrl?: string;
  videoUrl?: string;
  frames?: string[];
  mediaType?: string;
  mood?: string;
};

// 100% Free Unlimited Mode: all generation costs are set to 0
export const GEN_COST: Record<string, number> = {
  portrait: 0,
  lingerie: 0,
  nude: 0,
  explicit: 0,
  video: 0,
};

const COINS_KEY = "vm-coins";
const DAILY_KEY = "vm-daily-ts";
const GALLERY_KEY = "vm-gallery";
const CHAT_PREFIX = "vm-chat-";
const INTIMACY_PREFIX = "vm-intimacy-";

export function getCoins(): number {
  if (typeof window === "undefined") return 9999;
  try {
    const raw = localStorage.getItem(COINS_KEY);
    if (!raw) return 9999;
    const n = parseInt(raw, 10);
    return Number.isFinite(n) && n >= 0 ? n : 9999;
  } catch {
    return 9999;
  }
}

export function setCoins(n: number): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(COINS_KEY, String(Math.max(0, Math.floor(n))));
  } catch {}
}

export function spendCoins(cost: number): boolean {
  if (cost <= 0) return true;
  const current = getCoins();
  if (current < cost) return false;
  setCoins(current - cost);
  return true;
}

export function addCoins(amount: number): void {
  const current = getCoins();
  setCoins(current + Math.max(0, amount));
}

export function canClaimDaily(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const last = parseInt(localStorage.getItem(DAILY_KEY) || "0", 10);
    return Date.now() - last > 20 * 60 * 60 * 1000;
  } catch {
    return false;
  }
}

export function claimDaily(): number {
  if (typeof window === "undefined") return getCoins();
  try {
    localStorage.setItem(DAILY_KEY, String(Date.now()));
    addCoins(250);
  } catch {}
  return getCoins();
}

export function getGallery(): GalleryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(GALLERY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function getCharacterGallery(characterId: string): GalleryItem[] {
  return getGallery().filter((item) => item.characterId === characterId);
}

export function addToGallery(
  item: Omit<GalleryItem, "id" | "createdAt">
): GalleryItem | undefined {
  if (typeof window === "undefined") return undefined;
  try {
    const next: GalleryItem = {
      ...item,
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: Date.now(),
    };
    const updated = [next, ...getGallery()].slice(0, 120);
    localStorage.setItem(GALLERY_KEY, JSON.stringify(updated));
    return next;
  } catch {
    return undefined;
  }
}

export function clearGallery(): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(GALLERY_KEY);
  } catch {}
}

export function loadChat(characterId: string): StoredMessage[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(`${CHAT_PREFIX}${characterId}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveChat(characterId: string, messages: StoredMessage[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(`${CHAT_PREFIX}${characterId}`, JSON.stringify(messages.slice(-80)));
  } catch {}
}

export function getIntimacy(characterId: string, fallback = 50): number {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(`${INTIMACY_PREFIX}${characterId}`);
    if (!raw) return fallback;
    const n = parseInt(raw, 10);
    return Number.isFinite(n) ? Math.min(100, Math.max(0, n)) : fallback;
  } catch {
    return fallback;
  }
}

export function bumpIntimacy(characterId: string, delta = 2): number {
  const next = Math.min(100, Math.max(0, getIntimacy(characterId, 50) + delta));
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(`${INTIMACY_PREFIX}${characterId}`, String(next));
    } catch {}
  }
  return next;
}
