export type PlayerGender = "guy" | "girl" | "nonbinary";

export type LocalUser = {
  username: string;
  joinedAt: number;
  uid?: string;
  email?: string | null;
  isFirebase?: boolean;
  gender?: PlayerGender;
  age?: number;
  bio?: string;
  archetype?: string;
  lookingFor?: "girl" | "guy" | "both";
  avatarUrl?: string;
};

const USER_KEY = "vm-user";

export function getUser(): LocalUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<LocalUser>;
    if (!parsed || typeof parsed.username !== "string" || parsed.username.trim().length < 2) {
      return null;
    }
    return {
      username: parsed.username.trim().slice(0, 24),
      joinedAt: typeof parsed.joinedAt === "number" ? parsed.joinedAt : Date.now(),
      uid: parsed.uid,
      email: parsed.email ?? null,
      isFirebase: Boolean(parsed.isFirebase),
      gender: parsed.gender ?? "guy",
      age: typeof parsed.age === "number" ? parsed.age : 24,
      bio: typeof parsed.bio === "string" ? parsed.bio : "Here for late-night banter, chemistry, and unforgettable roleplay.",
      archetype: typeof parsed.archetype === "string" ? parsed.archetype : "Confident Charmer",
      lookingFor: parsed.lookingFor ?? "girl",
      avatarUrl: parsed.avatarUrl,
    };
  } catch {
    return null;
  }
}

export function login(
  username: string,
  extra?: Partial<Omit<LocalUser, "username" | "joinedAt">>
): LocalUser | null {
  const clean = username.trim().slice(0, 24);
  if (clean.length < 2) return null;
  const existing = getUser();
  const user: LocalUser = {
    username: clean,
    joinedAt: existing?.joinedAt ?? Date.now(),
    gender: extra?.gender ?? existing?.gender ?? "guy",
    age: extra?.age ?? existing?.age ?? 24,
    bio:
      extra?.bio ??
      existing?.bio ??
      "Here for late-night banter, chemistry, and unforgettable roleplay.",
    archetype: extra?.archetype ?? existing?.archetype ?? "Confident Charmer",
    lookingFor: extra?.lookingFor ?? existing?.lookingFor ?? "girl",
    avatarUrl: extra?.avatarUrl ?? existing?.avatarUrl,
    uid: extra?.uid ?? existing?.uid,
    email: extra?.email ?? existing?.email ?? null,
    isFirebase: extra?.isFirebase ?? existing?.isFirebase ?? false,
  };
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } catch {
      // Ignore storage quota errors
    }
  }
  return user;
}

export function updateUserProfile(patch: Partial<LocalUser>): LocalUser | null {
  const current = getUser() ?? {
    username: "VIP Guest",
    joinedAt: Date.now(),
    gender: "guy" as PlayerGender,
    age: 24,
    bio: "Here for late-night banter, chemistry, and unforgettable roleplay.",
    archetype: "Confident Charmer",
    lookingFor: "girl" as const,
  };
  const updated: LocalUser = {
    ...current,
    ...patch,
    username: (patch.username ?? current.username).trim().slice(0, 24) || current.username,
  };
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(USER_KEY, JSON.stringify(updated));
    } catch {
      // Ignore storage quota errors
    }
  }
  return updated;
}

export function logout(): void {
  if (typeof window !== "undefined") {
    try {
      localStorage.removeItem(USER_KEY);
    } catch {
      // Ignore storage errors
    }
    import("@/lib/firebase")
      .then((m) => m.firebaseLogout?.())
      .catch(() => {});
  }
}
