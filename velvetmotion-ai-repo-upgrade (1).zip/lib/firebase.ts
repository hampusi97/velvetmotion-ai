import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  type Auth,
  type User,
} from "firebase/auth";
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp,
  type Firestore,
} from "firebase/firestore";
import { login, type LocalUser } from "@/lib/auth";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "",
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: "select_account",
});

export function isFirebaseConfigured(): boolean {
  return Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
}

export function initFirebase() {
  if (typeof window === "undefined" || !isFirebaseConfigured()) {
    return { app: null, auth: null, db: null };
  }
  if (!app) {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
  }
  return { app, auth, db };
}

export function initAuth() {
  return initFirebase().auth;
}

export function subscribeAuthState(callback: (user: LocalUser | null) => void): () => void {
  const { auth: firebaseAuth } = initFirebase();
  if (!firebaseAuth) return () => {};
  return onAuthStateChanged(firebaseAuth, (fbUser: User | null) => {
    if (!fbUser) {
      callback(null);
      return;
    }
    const displayName = fbUser.displayName || fbUser.email?.split("@")[0] || "VIP Member";
    const local = login(displayName, {
      uid: fbUser.uid,
      email: fbUser.email,
      isFirebase: true,
      avatarUrl: fbUser.photoURL || undefined,
    });
    callback(local);
  });
}

export async function signInWithGoogle(): Promise<LocalUser | null> {
  const { auth: firebaseAuth, db: firestore } = initFirebase();
  if (!firebaseAuth) {
    throw new Error("Firebase is not configured. Use instant free guest login instead.");
  }
  const result = await signInWithPopup(firebaseAuth, googleProvider);
  const fbUser = result.user;
  const displayName = fbUser.displayName || fbUser.email?.split("@")[0] || "VIP Member";

  if (firestore) {
    try {
      const userRef = doc(firestore, "users", fbUser.uid);
      const snap = await getDoc(userRef);
      if (!snap.exists()) {
        await setDoc(userRef, {
          uid: fbUser.uid,
          username: displayName.slice(0, 32),
          coins: 999,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch {
      // Non-fatal if Firestore rules or offline state block initial sync
    }
  }

  return login(displayName, {
    uid: fbUser.uid,
    email: fbUser.email,
    isFirebase: true,
    avatarUrl: fbUser.photoURL || undefined,
  });
}

export async function syncChatSessionToFirestore(params: {
  uid: string;
  characterId: string;
  intimacy: number;
  gifts: string[];
  lastMessage: string;
}): Promise<void> {
  const { db: firestore } = initFirebase();
  if (!firestore || !params.uid) return;
  try {
    const chatId = `${params.uid}_${params.characterId}`;
    const ref = doc(firestore, "chats", chatId);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        uid: params.uid,
        characterId: params.characterId,
        intimacy: Math.min(100, Math.max(0, params.intimacy)),
        gifts: params.gifts.slice(0, 20),
        lastMessage: params.lastMessage.slice(0, 2000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        intimacy: Math.min(100, Math.max(0, params.intimacy)),
        gifts: params.gifts.slice(0, 20),
        lastMessage: params.lastMessage.slice(0, 2000),
        updatedAt: serverTimestamp(),
      });
    }
  } catch {
    // Fallback remains in localStorage
  }
}

export async function firebaseLogout(): Promise<void> {
  const { auth: firebaseAuth } = initFirebase();
  if (firebaseAuth) {
    await signOut(firebaseAuth);
  }
}
