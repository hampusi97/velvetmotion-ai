"use client";

import { useState, useEffect, useRef } from "react";
import type { Character } from "@/lib/charactersTypes";
import { CHARACTERS } from "@/lib/characters";
import { getUser } from "@/lib/auth";
import { speak, stopSpeaking } from "@/lib/speech";
import { GIFTS, addGift, getGiftsFor } from "@/lib/gifts";
import {
  addToGallery,
  bumpIntimacy,
  getCharacterGallery,
  getIntimacy,
  loadChat,
  saveChat,
  type GalleryItem,
} from "@/lib/storage";

export interface CharacterChatProps {
  character: Character;
  romanceMode: boolean;
  onBack: () => void;
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  swipes?: string[];
  swipeIndex?: number;
  imageUrl?: string;
  videoUrl?: string;
  frames?: string[];
  mediaType?: string;
  mood?: string;
}

const GEN_TYPES = [
  { id: "portrait", label: "Glamour Photo (Free)" },
  { id: "lingerie", label: "Silk Lingerie (Free)" },
  { id: "nude", label: "Uncensored Boudoir (Free)" },
  { id: "explicit", label: "Explicit Fantasy (Free)" },
  { id: "video", label: "Motion Video Loop (Free)" },
] as const;

const POSES = [
  "Over-the-shoulder seductive bedroom glance",
  "Luxury penthouse jacuzzi by candlelight",
  "Full-length mirror selfie in silk lace",
  "Leaning forward on velvet lounge sofa",
  "Playful kneeling pose with warm eye contact",
];

export function CharacterChat({ character, romanceMode, onBack }: CharacterChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: character.initialMessage,
      swipes: [character.initialMessage],
      swipeIndex: 0,
      mood: romanceMode ? "Affectionate" : "Flirty & Teasing",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [genOpen, setGenOpen] = useState(false);
  const [giftOpen, setGiftOpen] = useState(false);
  const [callOpen, setCallOpen] = useState(false);
  const [genType, setGenType] = useState<(typeof GEN_TYPES)[number]["id"]>("portrait");
  const [pose, setPose] = useState<string>(POSES[0]);
  const [extra, setExtra] = useState("");
  const [dualId, setDualId] = useState("");
  const [genLoading, setGenLoading] = useState(false);
  const [intimacy, setIntimacy] = useState<number>(character.intimacy);
  const [giftIds, setGiftIds] = useState<string[]>([]);
  const [profileMedia, setProfileMedia] = useState<GalleryItem[]>([]);
  const [authorsNote, setAuthorsNote] = useState(
    "Private penthouse suite at midnight, soft neon lighting, intense chemistry"
  );
  const [memories, setMemories] = useState<string[]>([
    `Loves your vibe and ${character.kink.toLowerCase()}`,
  ]);
  const [newMemory, setNewMemory] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stored = loadChat(character.id);
    if (stored.length > 0) {
      setMessages(
        stored.map((m) => ({
          ...m,
          swipes: [m.content],
          swipeIndex: 0,
        }))
      );
    } else {
      setMessages([
        {
          role: "assistant",
          content: character.initialMessage,
          swipes: [character.initialMessage],
          swipeIndex: 0,
          mood: romanceMode ? "Affectionate" : "Flirty & Teasing",
        },
      ]);
    }
    setIntimacy(getIntimacy(character.id, character.intimacy));
    setGiftIds(getGiftsFor(character.id));
    setProfileMedia(getCharacterGallery(character.id));
  }, [character.id, character.initialMessage, character.intimacy, romanceMode]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const persistMessages = (next: ChatMessage[]) => {
    setMessages(next);
    saveChat(
      character.id,
      next.map((m) => ({
        role: m.role,
        content: m.content,
        imageUrl: m.imageUrl,
        videoUrl: m.videoUrl,
        frames: m.frames,
        mediaType: m.mediaType,
        mood: m.mood,
      }))
    );
  };

  const handleSend = async (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if (!text || isLoading) return;
    if (!overrideText) setInput("");

    const user = getUser();
    const userMsg: ChatMessage = { role: "user", content: text };
    const updated = [...messages, userMsg];
    persistMessages(updated);
    setIsLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          characterName: character.name,
          personality: character.personality,
          kink: character.kink,
          userName: user?.username || "handsome",
          intimacy,
          systemPrompt: `You are ${character.name} (${character.age}). Personality: ${character.personality}. Figure: ${character.figure}. Kink: ${character.kink}. Scene Direction: ${authorsNote}. Key Memories: ${memories.join("; ")}. User Persona: ${user?.username || "VIP"} (${user?.gender || "guy"}, ${user?.archetype || "Charmer"}). Respond in first person with expressive *actions* and natural dialogue.`,
          messages: updated.slice(-16).map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await res.json();
      const replyText =
        typeof data?.reply === "string" && data.reply.trim()
          ? data.reply.trim()
          : `*moves closer and locks eyes with you* "I love the way you talk to me..."`;
      const nextIntimacy = bumpIntimacy(character.id, 3);
      setIntimacy(nextIntimacy);
      persistMessages([
        ...updated,
        {
          role: "assistant",
          content: replyText,
          swipes: [replyText],
          swipeIndex: 0,
          mood: data?.mood || "Flirty & Teasing",
        },
      ]);
    } catch {
      persistMessages([
        ...updated,
        {
          role: "assistant",
          content: `*smiles softly and leans against your shoulder* "Tell me more—you have my complete attention tonight."`,
          swipes: [
            `*smiles softly and leans against your shoulder* "Tell me more—you have my complete attention tonight."`,
          ],
          swipeIndex: 0,
          mood: "Affectionate",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSwipeMessage = (idx: number, dir: number) => {
    const target = messages[idx];
    if (!target || target.role !== "assistant") return;
    const swipes = Array.isArray(target.swipes) && target.swipes.length > 0 ? [...target.swipes] : [target.content];
    let nextIdx = (target.swipeIndex ?? 0) + dir;
    if (nextIdx >= swipes.length) {
      swipes.push(
        `*bites her lip under the ${authorsNote.slice(0, 30)} lighting* "You really know how to make my pulse race. What happens if I let you take complete control right now?"`
      );
    }
    nextIdx = Math.max(0, nextIdx);
    const copy = [...messages];
    copy[idx] = {
      ...target,
      swipes,
      swipeIndex: nextIdx,
      content: swipes[nextIdx % swipes.length],
    };
    persistMessages(copy);
  };

  const handleGenerateMedia = async () => {
    if (genLoading) return;
    setGenLoading(true);
    try {
      const dualCompanion = CHARACTERS.find((c) => c.id === dualId);
      if (genType === "video") {
        const res = await fetch("/api/generate-video", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            characterName: character.name,
            appearance: `${character.figure}, ${character.personality}`,
            pose,
            aspectRatio: "9:16",
          }),
        });
        const data = await res.json();
        const url = data?.url || character.avatar;
        addToGallery({
          characterId: character.id,
          characterName: character.name,
          type: "video",
          url,
          frames: Array.isArray(data?.frames) ? data.frames : undefined,
          prompt: `${character.name} • ${pose}`,
        });
        setProfileMedia(getCharacterGallery(character.id));
        persistMessages([
          ...messages,
          {
            role: "assistant",
            content: `*records a private motion video loop (${pose}) and pins it to her profile gallery for you*`,
            imageUrl: url,
            frames: Array.isArray(data?.frames) ? data.frames : undefined,
            mediaType: "video",
            mood: "Exhibitionist",
          },
        ]);
      } else {
        const res = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            characterName: character.name,
            appearance: `${character.figure}, ${character.personality}`,
            type: genType,
            pose,
            extra,
            dual: dualCompanion?.name || "",
          }),
        });
        const data = await res.json();
        const url = data?.url || character.avatar;
        addToGallery({
          characterId: character.id,
          characterName: character.name,
          type: genType,
          url,
          prompt: `${character.name} • ${genType.toUpperCase()} • ${pose}`,
        });
        setProfileMedia(getCharacterGallery(character.id));
        persistMessages([
          ...messages,
          {
            role: "assistant",
            content: `*sends you a private ${genType} photo (${pose}) and saves it into her profile*`,
            imageUrl: url,
            mediaType: genType,
            mood: "Exhibitionist",
          },
        ]);
      }
      setIntimacy(bumpIntimacy(character.id, 5));
      setGenOpen(false);
    } finally {
      setGenLoading(false);
    }
  };

  const handleSendGift = (giftId: string) => {
    const gift = GIFTS.find((g) => g.id === giftId);
    if (!gift) return;
    setGiftIds(addGift(character.id, gift.id));
    setIntimacy(bumpIntimacy(character.id, 6));
    persistMessages([
      ...messages,
      { role: "user", content: `*gifts ${character.name} ${gift.name}*` },
      {
        role: "assistant",
        content: gift.line,
        swipes: [gift.line],
        swipeIndex: 0,
        mood: "Adoring",
      },
    ]);
    setGiftOpen(false);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-4 text-white">
      <div className="grid lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-8 bg-zinc-950 border border-white/10 rounded-3xl overflow-hidden flex flex-col h-[700px] shadow-2xl">
          <div className="p-4 border-b border-white/10 flex items-center justify-between gap-3 bg-zinc-900/60">
            <div className="flex items-center gap-3">
              <button onClick={() => { stopSpeaking(); onBack(); }} className="text-xs text-pink-400 hover:underline">
                ← Profile
              </button>
              <img src={character.avatar} alt={character.name} className="w-11 h-11 rounded-2xl object-cover border border-pink-500/40" />
              <div>
                <div className="font-extrabold text-sm">{character.name}, {character.age}</div>
                <div className="text-[11px] text-emerald-400">● Online • Intimacy {intimacy}% • Free Mode</div>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={() => setCallOpen(true)} className="px-3 py-1.5 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
                📞 Call Live
              </button>
              <button onClick={() => setGenOpen((v) => !v)} className="px-3 py-1.5 rounded-xl bg-pink-600 text-white text-xs font-semibold">
                📸 Free Photo/Video
              </button>
              <button onClick={() => setGiftOpen((v) => !v)} className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-white/10 text-xs font-semibold">
                🎁 Free Gift ({giftIds.length})
              </button>
            </div>
          </div>

          {genOpen && (
            <div className="p-4 bg-zinc-900/95 border-b border-pink-500/30 space-y-3">
              <div className="flex flex-wrap gap-2">
                {GEN_TYPES.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => setGenType(g.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                      genType === g.id ? "bg-pink-600 text-white" : "bg-zinc-800 text-zinc-300"
                    }`}
                  >
                    {g.label}
                  </button>
                ))}
              </div>
              <div className="grid sm:grid-cols-3 gap-2">
                <select value={pose} onChange={(e) => setPose(e.target.value)} className="bg-zinc-950 border border-white/10 rounded-xl px-3 py-2 text-xs">
                  {POSES.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
                <input value={extra} onChange={(e) => setExtra(e.target.value)} placeholder="Extra lighting / outfit details..." className="bg-zinc-950 border border-white/10 rounded-xl px-3 py-2 text-xs" />
                <select value={dualId} onChange={(e) => setDualId(e.target.value)} className="bg-zinc-950 border border-white/10 rounded-xl px-3 py-2 text-xs">
                  <option value="">Solo Shot</option>
                  {CHARACTERS.filter((c) => c.id !== character.id).map((c) => (
                    <option key={c.id} value={c.id}>+ Dual with {c.name}</option>
                  ))}
                </select>
              </div>
              <button onClick={handleGenerateMedia} disabled={genLoading} className="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-fuchsia-600 text-xs font-bold">
                {genLoading ? "Generating & Pinning to Her Profile..." : "Generate Now (0 Coins • Free)"}
              </button>
            </div>
          )}

          {giftOpen && (
            <div className="p-4 bg-zinc-900/95 border-b border-white/10 grid grid-cols-2 sm:grid-cols-5 gap-2">
              {GIFTS.map((g) => (
                <button key={g.id} onClick={() => handleSendGift(g.id)} className="p-2.5 rounded-xl bg-zinc-950 hover:bg-pink-600/20 border border-white/10 text-left">
                  <div className="text-xs font-bold">{g.name}</div>
                  <div className="text-[10px] text-emerald-400">Free Gift</div>
                </button>
              ))}
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {messages.map((m, i) => {
              const swipes = Array.isArray(m.swipes) && m.swipes.length > 0 ? m.swipes : [m.content];
              const sIdx = m.swipeIndex ?? 0;
              return (
                <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[82%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                    m.role === "user" ? "bg-gradient-to-r from-pink-600 to-fuchsia-600 text-white" : "bg-zinc-900 border border-white/10 text-zinc-100"
                  }`}>
                    <div className="whitespace-pre-line">{m.content}</div>
                    {m.imageUrl && (
                      <div className="mt-3 rounded-xl overflow-hidden border border-pink-500/40">
                        <img src={m.imageUrl} alt={character.name} className="w-full max-h-80 object-cover" />
                      </div>
                    )}
                    {m.role === "assistant" && (
                      <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between gap-3 text-[10px] text-zinc-400">
                        <div className="flex items-center gap-1.5">
                          <button onClick={() => handleSwipeMessage(i, -1)} className="px-1.5 py-0.5 rounded bg-zinc-800 hover:text-white">‹</button>
                          <span className="text-pink-400 font-semibold">{(sIdx % swipes.length) + 1}/{swipes.length}</span>
                          <button onClick={() => handleSwipeMessage(i, 1)} className="px-1.5 py-0.5 rounded bg-zinc-800 hover:text-white">›</button>
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={() => speak(m.content, character.voice)} className="text-pink-400 hover:underline">🔊 Speak</button>
                          <button onClick={() => setMemories((prev) => [m.content.slice(0, 65), ...prev])} className="text-emerald-400 hover:underline">+ Remember</button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>

          <div className="p-4 bg-zinc-900/80 border-t border-white/10 flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder={`Message ${character.name}...`}
              className="flex-1 bg-zinc-950 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white"
            />
            <button onClick={() => handleSend()} disabled={isLoading} className="px-6 py-3 rounded-2xl bg-gradient-to-r from-pink-600 to-fuchsia-600 text-xs font-bold">
              {isLoading ? "..." : "Send"}
            </button>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-4">
          <div className="bg-zinc-950 border border-white/10 rounded-3xl p-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-pink-400">Memory Journal & Scene Director</h3>
            <input
              value={authorsNote}
              onChange={(e) => setAuthorsNote(e.target.value)}
              placeholder="Active Scene Direction..."
              className="w-full bg-zinc-900 border border-white/10 rounded-xl px-3 py-2 text-xs"
            />
            <div className="flex gap-1.5">
              <input
                value={newMemory}
                onChange={(e) => setNewMemory(e.target.value)}
                placeholder="Pin memory fact..."
                className="flex-1 bg-zinc-900 border border-white/10 rounded-xl px-3 py-1.5 text-xs"
              />
              <button
                onClick={() => {
                  if (!newMemory.trim()) return;
                  setMemories((prev) => [newMemory.trim(), ...prev]);
                  setNewMemory("");
                }}
                className="px-3 py-1.5 rounded-xl bg-pink-600 text-xs font-bold"
              >
                Add
              </button>
            </div>
            <div className="space-y-1.5 max-h-32 overflow-y-auto text-[11px] text-zinc-300">
              {memories.map((mem, idx) => (
                <div key={idx} className="p-2 rounded-lg bg-zinc-900 border border-white/5">🧠 {mem}</div>
              ))}
            </div>
          </div>

          <div className="bg-zinc-950 border border-white/10 rounded-3xl p-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              {character.name}'s Profile Media ({profileMedia.length + 1})
            </h3>
            <div className="grid grid-cols-2 gap-2.5">
              <img src={character.avatar} alt={character.name} className="w-full aspect-[3/4] object-cover rounded-xl border border-white/10" />
              {profileMedia.slice(0, 3).map((item) => (
                <img key={item.id} src={item.url} alt={item.prompt || character.name} className="w-full aspect-[3/4] object-cover rounded-xl border border-pink-500/30" />
              ))}
            </div>
          </div>
        </div>
      </div>

      {callOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="max-w-sm w-full bg-zinc-950 border border-pink-500/40 rounded-3xl p-6 text-center space-y-4">
            <img src={character.avatar} alt={character.name} className="w-28 h-28 rounded-full object-cover mx-auto border-2 border-pink-500" />
            <h3 className="text-xl font-bold">{character.name} • Live Voice Call</h3>
            <p className="text-xs text-zinc-300 italic">"{character.voiceIntro}"</p>
            <div className="flex gap-2">
              <button onClick={() => speak(character.voiceIntro, character.voice)} className="flex-1 py-2.5 rounded-xl bg-pink-600 text-xs font-bold">
                🔊 Speak Again
              </button>
              <button onClick={() => { stopSpeaking(); setCallOpen(false); }} className="flex-1 py-2.5 rounded-xl bg-rose-600 text-xs font-bold">
                End Call
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
