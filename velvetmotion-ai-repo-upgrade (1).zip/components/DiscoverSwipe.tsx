"use client";

import { useState, useEffect } from "react";
import type { Character } from "@/lib/charactersTypes";
import { CHARACTERS } from "@/lib/characters";
import { getUser, updateUserProfile, type PlayerGender } from "@/lib/auth";
import { addToGallery } from "@/lib/storage";

export interface DiscoverSwipeProps {
  onMatch?: (c: Character) => void;
  onHome?: () => void;
  onChat?: (c: Character) => void;
  onBack?: () => void;
  extra?: Character[];
}

type TinderMode = "swipe" | "be-the-crush" | "my-profile";

export function DiscoverSwipe({
  onMatch,
  onHome,
  onChat,
  onBack,
  extra = [],
}: DiscoverSwipeProps) {
  const handleHome = () => {
    if (onHome) onHome();
    else if (onBack) onBack();
  };

  const handleOpenChat = (c: Character) => {
    if (onMatch) onMatch(c);
    else if (onChat) onChat(c);
  };

  const [mode, setMode] = useState<TinderMode>("swipe");
  const [playerGender, setPlayerGender] = useState<PlayerGender>("guy");
  const [playerName, setPlayerName] = useState("Alex");
  const [playerAge, setPlayerAge] = useState(24);
  const [playerArchetype, setPlayerArchetype] = useState("Confident Charmer");
  const [playerBio, setPlayerBio] = useState(
    "Late-night drives, rooftop drinks, and someone who can keep up with my banter."
  );
  const [profileSavedMsg, setProfileSavedMsg] = useState("");

  const [deck, setDeck] = useState<Character[]>([]);
  const [idx, setIdx] = useState(0);
  const [matches, setMatches] = useState<Character[]>([]);
  const [showMatch, setShowMatch] = useState<Character | null>(null);
  const [incomingLine, setIncomingLine] = useState<string>("");
  const [spicyPeek, setSpicyPeek] = useState(false);

  useEffect(() => {
    const u = getUser();
    if (u) {
      setPlayerName(u.username);
      if (u.gender) setPlayerGender(u.gender);
      if (u.age) setPlayerAge(u.age);
      if (u.archetype) setPlayerArchetype(u.archetype);
      if (u.bio) setPlayerBio(u.bio);
    }
    setDeck([...extra, ...CHARACTERS]);
  }, [extra]);

  const currentCard = deck[idx % Math.max(1, deck.length)];

  const savePlayerProfile = () => {
    updateUserProfile({
      username: playerName,
      gender: playerGender,
      age: playerAge,
      archetype: playerArchetype,
      bio: playerBio,
    });
    setProfileSavedMsg("Profile saved! Companions will now react to your persona.");
    setTimeout(() => setProfileSavedMsg(""), 3000);
  };

  const buildPersonalizedOpener = (c: Character) => {
    const roleLabel =
      playerGender === "girl"
        ? "gorgeous girl"
        : playerGender === "nonbinary"
        ? "mysterious match"
        : "handsome guy";
    return `Hey ${playerName}! I saw your "${playerArchetype}" profile (${roleLabel}, ${playerAge}) and your bio ("${playerBio.slice(
      0,
      55
    )}...") — I immediately super-liked you. What are we doing tonight?`;
  };

  const triggerMatch = (c: Character, superLike = false) => {
    if (!matches.some((m) => m.id === c.id)) {
      setMatches((prev) => [c, ...prev]);
    }
    const opener = superLike
      ? `*SUPER-MATCH!* ${buildPersonalizedOpener(c)}`
      : buildPersonalizedOpener(c);
    setIncomingLine(opener);
    setShowMatch(c);
  };

  const handlePass = () => {
    setSpicyPeek(false);
    setIdx((prev) => prev + 1);
  };

  const handleLike = (superLike = false) => {
    if (!currentCard) return;
    setSpicyPeek(false);
    triggerMatch(currentCard, superLike);
    setIdx((prev) => prev + 1);
  };

  const generateProfileCardPhoto = async (c: Character) => {
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      `8k photorealistic tinder dating profile selfie of ${c.name}, ${c.figure}, ${c.personality}, flirty smile, luxury evening lighting`
    )}?width=720&height=960&seed=${Date.now() % 100000}&model=flux&nologo=true`;
    addToGallery({
      characterId: c.id,
      characterName: c.name,
      type: "portrait",
      url,
      prompt: `${c.name} Tinder Match Selfie`,
    });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 text-white">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <button
            onClick={handleHome}
            className="text-xs uppercase tracking-widest text-pink-400 hover:text-pink-300 mb-1 block"
          >
            ← Back to VelvetMotion Hub
          </button>
          <h1 className="text-3xl font-extrabold tracking-tight">
            VelvetSwipe • Two-Way Tinder Roleplay
          </h1>
          <p className="text-sm text-zinc-400">
            Play as a Guy or Girl, customize your dating card, and match with AI companions for free.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-zinc-900/90 border border-white/10 p-1.5 rounded-2xl">
          <button
            onClick={() => setMode("swipe")}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
              mode === "swipe" ? "bg-pink-600 text-white" : "text-zinc-400 hover:text-white"
            }`}
          >
            Swipe Deck
          </button>
          <button
            onClick={() => setMode("be-the-crush")}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
              mode === "be-the-crush" ? "bg-pink-600 text-white" : "text-zinc-400 hover:text-white"
            }`}
          >
            They Swipe On You
          </button>
          <button
            onClick={() => setMode("my-profile")}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
              mode === "my-profile" ? "bg-pink-600 text-white" : "text-zinc-400 hover:text-white"
            }`}
          >
            My Roleplay Profile ({playerGender === "girl" ? "Girl" : playerGender === "guy" ? "Guy" : "Custom"})
          </button>
        </div>
      </div>

      {mode === "my-profile" && (
        <div className="grid md:grid-cols-2 gap-6 bg-zinc-950/90 border border-white/10 rounded-3xl p-6">
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Customize Who You Play As</h2>
            <div>
              <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-2">
                I Am Playing As
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    { id: "guy", label: "Play as Guy" },
                    { id: "girl", label: "Play as Girl" },
                    { id: "nonbinary", label: "Custom / NB" },
                  ] as const
                ).map((g) => (
                  <button
                    key={g.id}
                    onClick={() => setPlayerGender(g.id)}
                    className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition ${
                      playerGender === g.id
                        ? "bg-pink-600/20 border-pink-500 text-pink-300"
                        : "bg-zinc-900 border-white/10 text-zinc-400"
                    }`}
                  >
                    {g.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-zinc-400 mb-1">Your Display Name</label>
                <input
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">Age (18+)</label>
                <input
                  type="number"
                  min={18}
                  max={99}
                  value={playerAge}
                  onChange={(e) => setPlayerAge(Math.max(18, parseInt(e.target.value, 10) || 18))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl px-3 py-2 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-zinc-400 mb-1">Your Dating Vibe / Archetype</label>
              <div className="flex flex-wrap gap-2">
                {[
                  "Confident Charmer",
                  "Dominant VIP",
                  "Playful Tease",
                  "Hopeless Romantic",
                  "Shy & Curious",
                  "Bad Boy / Bad Girl",
                ].map((arch) => (
                  <button
                    key={arch}
                    onClick={() => setPlayerArchetype(arch)}
                    className={`px-3 py-1.5 rounded-full text-xs border transition ${
                      playerArchetype === arch
                        ? "bg-pink-600 border-pink-500 text-white"
                        : "bg-zinc-900 border-white/10 text-zinc-400"
                    }`}
                  >
                    {arch}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-zinc-400 mb-1">Your Bio (Companions read this!)</label>
              <textarea
                value={playerBio}
                onChange={(e) => setPlayerBio(e.target.value)}
                rows={3}
                className="w-full bg-zinc-900 border border-white/10 rounded-xl p-3 text-sm"
              />
            </div>

            <button
              onClick={savePlayerProfile}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-600 to-fuchsia-600 font-semibold text-sm shadow-lg"
            >
              Save My Tinder Persona
            </button>
            {profileSavedMsg && (
              <p className="text-xs text-emerald-400 text-center">{profileSavedMsg}</p>
            )}
          </div>

          <div className="bg-zinc-900/70 border border-white/10 rounded-3xl p-6 flex flex-col justify-between">
            <div>
              <span className="inline-block text-[10px] uppercase tracking-widest px-3 py-1 rounded-full bg-pink-500/20 text-pink-300 mb-3">
                Live Preview • Your Dating Card
              </span>
              <h3 className="text-2xl font-extrabold">
                {playerName}, {playerAge}
              </h3>
              <p className="text-xs text-pink-400 font-medium mt-0.5">
                Playing as {playerGender.toUpperCase()} • {playerArchetype}
              </p>
              <p className="text-sm text-zinc-300 mt-4 leading-relaxed">"{playerBio}"</p>
            </div>
            <div className="mt-6 pt-4 border-t border-white/10 text-xs text-zinc-400">
              Every match uses your name, gender, archetype, and bio to craft custom opening messages in chat.
            </div>
          </div>
        </div>
      )}

      {mode === "swipe" && currentCard && (
        <div className="grid md:grid-cols-12 gap-6 items-start">
          <div className="md:col-span-7 bg-zinc-950 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
            <div className="relative aspect-[4/5] bg-zinc-900">
              <img
                src={currentCard.avatar}
                alt={currentCard.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
              <div className="absolute top-4 left-4 flex gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-black/70 border border-white/15">
                  {currentCard.category}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-pink-600/80">
                  100% Free Match
                </span>
              </div>
              <div className="absolute bottom-5 left-5 right-5">
                <h2 className="text-3xl font-extrabold">
                  {currentCard.name}, {currentCard.age}
                </h2>
                <p className="text-sm text-zinc-300 mt-1">{currentCard.tagline}</p>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {currentCard.tags.map((t) => (
                    <span
                      key={t}
                      className="text-[11px] px-2.5 py-0.5 rounded-full bg-white/10 text-zinc-200"
                    >
                      {t}
                    </span>
                  ))}
                </div>
                {spicyPeek && (
                  <div className="mt-3 p-3 rounded-2xl bg-black/80 border border-pink-500/40 text-xs text-pink-200">
                    <strong>Secret Turn-On:</strong> {currentCard.kink}
                  </div>
                )}
              </div>
            </div>

            <div className="p-5 flex items-center justify-between gap-3 bg-zinc-950">
              <button
                onClick={handlePass}
                className="flex-1 py-3.5 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-white/10 font-semibold text-sm"
              >
                ✕ Pass
              </button>
              <button
                onClick={() => setSpicyPeek((v) => !v)}
                className="px-4 py-3.5 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-pink-500/30 text-pink-300 text-xs font-semibold"
              >
                {spicyPeek ? "Hide Secret" : "Peek Turn-On"}
              </button>
              <button
                onClick={() => handleLike(true)}
                className="px-4 py-3.5 rounded-2xl bg-fuchsia-600/20 hover:bg-fuchsia-600/30 border border-fuchsia-500/40 text-fuchsia-300 text-xs font-semibold"
              >
                ★ Super-Like
              </button>
              <button
                onClick={() => handleLike(false)}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-pink-600 to-fuchsia-600 font-semibold text-sm shadow-lg"
              >
                ♥ Match Now
              </button>
            </div>
          </div>

          <div className="md:col-span-5 space-y-4">
            <div className="bg-zinc-950 border border-white/10 rounded-3xl p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase tracking-wider text-zinc-400">
                  Playing As
                </span>
                <button
                  onClick={() => setMode("my-profile")}
                  className="text-xs text-pink-400 hover:underline"
                >
                  Edit Persona →
                </button>
              </div>
              <div className="text-lg font-bold">
                {playerName}, {playerAge} ({playerGender.toUpperCase()})
              </div>
              <div className="text-xs text-pink-400">{playerArchetype}</div>
              <p className="text-xs text-zinc-400 mt-2 line-clamp-2">"{playerBio}"</p>
            </div>

            <div className="bg-zinc-950 border border-white/10 rounded-3xl p-5">
              <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-400 mb-3">
                Your Matches ({matches.length})
              </h3>
              {matches.length === 0 ? (
                <p className="text-xs text-zinc-500">
                  Hit Match Now or Super-Like to start an instant roleplay chat.
                </p>
              ) : (
                <div className="space-y-2.5 max-h-80 overflow-y-auto">
                  {matches.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-zinc-900/80 border border-white/10"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={m.avatar}
                          alt={m.name}
                          className="w-11 h-11 rounded-xl object-cover"
                        />
                        <div>
                          <div className="text-sm font-semibold">{m.name}</div>
                          <div className="text-[11px] text-zinc-400">{m.tagline}</div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleOpenChat(m)}
                        className="px-3 py-1.5 rounded-xl bg-pink-600 text-xs font-semibold"
                      >
                        Chat
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {mode === "be-the-crush" && (
        <div className="bg-zinc-950 border border-white/10 rounded-3xl p-6 space-y-5">
          <div>
            <h2 className="text-xl font-bold">
              Reverse Tinder Roleplay: Companions Swipe Right on {playerName}
            </h2>
            <p className="text-sm text-zinc-400">
              Companions react directly to your {playerGender.toUpperCase()} profile ({playerArchetype}) and send the first pickup line.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {deck.slice(0, 6).map((c) => (
              <div
                key={c.id}
                className="bg-zinc-900/80 border border-white/10 rounded-2xl p-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={c.avatar}
                      alt={c.name}
                      className="w-12 h-12 rounded-xl object-cover"
                    />
                    <div>
                      <div className="font-bold text-sm">
                        {c.name}, {c.age}
                      </div>
                      <div className="text-[11px] text-pink-400">Swiped Right on You!</div>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-300 italic bg-black/40 p-3 rounded-xl border border-white/5">
                    "{buildPersonalizedOpener(c)}"
                  </p>
                </div>
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => {
                      generateProfileCardPhoto(c);
                      handleOpenChat(c);
                    }}
                    className="flex-1 py-2 rounded-xl bg-pink-600 text-xs font-semibold"
                  >
                    Reply in Chat
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showMatch && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-zinc-950 border border-pink-500/40 rounded-3xl p-6 text-center space-y-4">
            <div className="text-xs uppercase tracking-widest text-pink-400 font-bold">
              It's a Match!
            </div>
            <img
              src={showMatch.avatar}
              alt={showMatch.name}
              className="w-28 h-28 rounded-full object-cover mx-auto border-2 border-pink-500"
            />
            <h3 className="text-2xl font-extrabold">
              You & {showMatch.name} Matched
            </h3>
            <p className="text-xs text-zinc-300 bg-zinc-900 p-3.5 rounded-2xl border border-white/10">
              {incomingLine}
            </p>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowMatch(null)}
                className="flex-1 py-3 rounded-2xl bg-zinc-900 border border-white/10 text-xs font-semibold"
              >
                Keep Swiping
              </button>
              <button
                onClick={() => {
                  const target = showMatch;
                  setShowMatch(null);
                  handleOpenChat(target);
                }}
                className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-pink-600 to-fuchsia-600 text-xs font-semibold"
              >
                Open Roleplay Chat →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
