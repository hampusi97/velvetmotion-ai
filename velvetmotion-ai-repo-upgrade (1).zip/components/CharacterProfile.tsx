"use client";

import { useState, useEffect } from "react";
import type { Character } from "@/lib/charactersTypes";
import { speak, stopSpeaking } from "@/lib/speech";
import {
  addToGallery,
  getCharacterGallery,
  getIntimacy,
  bumpIntimacy,
  type GalleryItem,
} from "@/lib/storage";

export interface CharacterProfileProps {
  character: Character;
  romanceMode: boolean;
  onBack: () => void;
  onChat: () => void;
  onTag: (tag: string) => void;
}

const PROFILE_POSES = [
  "Seductive over-the-shoulder bedroom glance",
  "Luxury rooftop lounge evening gown portrait",
  "Silk lace lingerie mirror selfie",
  "Candlelit jacuzzi close-up with wet hair",
  "Playful kneeling pose on velvet sofa",
];

export function CharacterProfile({
  character,
  romanceMode,
  onBack,
  onChat,
  onTag,
}: CharacterProfileProps) {
  const [tab, setTab] = useState<"overview" | "photos" | "videos">("overview");
  const [media, setMedia] = useState<GalleryItem[]>([]);
  const [pose, setPose] = useState(PROFILE_POSES[0]);
  const [styleType, setStyleType] = useState<"portrait" | "lingerie" | "nude" | "video">("portrait");
  const [busy, setBusy] = useState(false);
  const [intimacy, setIntimacy] = useState(character.intimacy);
  const [activeFrameIdx, setActiveFrameIdx] = useState(0);

  useEffect(() => {
    setMedia(getCharacterGallery(character.id));
    setIntimacy(getIntimacy(character.id, character.intimacy));
  }, [character.id, character.intimacy]);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveFrameIdx((i) => (i + 1) % 4);
    }, 900);
    return () => clearInterval(timer);
  }, []);

  const photos = media.filter((m) => m.type !== "video" && m.type !== "motion-loop");
  const videos = media.filter((m) => m.type === "video" || m.type === "motion-loop" || (m.frames && m.frames.length > 1));

  const handleGenerateIntoProfile = async () => {
    if (busy) return;
    setBusy(true);
    try {
      if (styleType === "video") {
        const res = await fetch("/api/generate-video", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            characterName: character.name,
            appearance: `${character.figure}, ${character.personality}`,
            pose,
            aspectRatio: "9:16",
          }),
        });
        const data = await res.json();
        const saved = addToGallery({
          characterId: character.id,
          characterName: character.name,
          type: "video",
          url: data.url || character.avatar,
          frames: Array.isArray(data.frames) ? data.frames : undefined,
          prompt: `${character.name} • ${pose}`,
        });
        if (saved) setMedia(getCharacterGallery(character.id));
        setTab("videos");
      } else {
        const res = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            characterName: character.name,
            appearance: `${character.figure}, ${character.personality}`,
            type: styleType,
            pose,
          }),
        });
        const data = await res.json();
        const saved = addToGallery({
          characterId: character.id,
          characterName: character.name,
          type: styleType,
          url: data.url || character.avatar,
          prompt: `${character.name} • ${styleType.toUpperCase()} • ${pose}`,
        });
        if (saved) setMedia(getCharacterGallery(character.id));
        setTab("photos");
      }
      setIntimacy(bumpIntimacy(character.id, 4));
    } catch {
      // Fallback direct generation
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 text-white">
      <button
        onClick={() => {
          stopSpeaking();
          onBack();
        }}
        className="text-xs uppercase tracking-widest text-pink-400 hover:text-pink-300 mb-4 inline-block"
      >
        ← Back to Companions
      </button>

      <div className="grid lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-5 bg-zinc-950 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
          <div className="relative aspect-[3/4]">
            <img
              src={photos[0]?.url || character.avatar}
              alt={character.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
            <div className="absolute top-4 left-4 flex gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-black/70 border border-white/15">
                {character.category}
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 border border-emerald-400/40 text-emerald-300">
                ● Online & Free
              </span>
            </div>
            <div className="absolute bottom-5 left-5 right-5">
              <h1 className="text-3xl font-extrabold">
                {character.name}, {character.age}
              </h1>
              <p className="text-sm text-zinc-300 mt-1">{character.tagline}</p>
              <div className="mt-3">
                <div className="flex justify-between text-xs text-zinc-300 mb-1">
                  <span>Intimacy Level</span>
                  <span className="text-pink-400 font-bold">{intimacy}%</span>
                </div>
                <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-500 to-fuchsia-500"
                    style={{ width: `${intimacy}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 space-y-3">
            <button
              onClick={onChat}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-pink-600 to-fuchsia-600 font-bold text-sm shadow-lg"
            >
              Start Live Chat ({romanceMode ? "Romance Mode" : "Uncensored Fantasy"})
            </button>
            <div className="flex gap-2">
              <button
                onClick={() => speak(character.voiceIntro, character.voice)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-xs font-semibold"
              >
                🔊 Hear Her Voice ({character.voice.label})
              </button>
              <button
                onClick={() => stopSpeaking()}
                className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-xs text-zinc-400"
              >
                Stop
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 space-y-6">
          {/* Direct Profile Media Generator Studio */}
          <div className="bg-zinc-950 border border-pink-500/30 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-widest px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 font-semibold">
                  Free Profile Studio
                </span>
                <h2 className="text-xl font-bold mt-1">
                  Generate Photos & Videos Into {character.name}'s Profile
                </h2>
              </div>
              <span className="text-xs text-emerald-400 font-semibold">0 Coins • Free</span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {(
                [
                  { id: "portrait", label: "Glamour Photo" },
                  { id: "lingerie", label: "Lingerie Set" },
                  { id: "nude", label: "Boudoir / Uncensored" },
                  { id: "video", label: "Motion Video Loop" },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setStyleType(item.id)}
                  className={`py-2.5 px-2 rounded-xl text-xs font-semibold border transition ${
                    styleType === item.id
                      ? "bg-pink-600 border-pink-500 text-white"
                      : "bg-zinc-900 border-white/10 text-zinc-400 hover:text-white"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <select
                value={pose}
                onChange={(e) => setPose(e.target.value)}
                className="flex-1 bg-zinc-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white"
              >
                {PROFILE_POSES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
              <button
                onClick={handleGenerateIntoProfile}
                disabled={busy}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-fuchsia-600 font-semibold text-xs disabled:opacity-50"
              >
                {busy
                  ? "Generating into Profile..."
                  : styleType === "video"
                  ? "Generate Profile Video (Free)"
                  : "Generate Profile Photo (Free)"}
              </button>
            </div>
          </div>

          {/* Profile Tabs */}
          <div className="flex gap-2 border-b border-white/10 pb-3">
            <button
              onClick={() => setTab("overview")}
              className={`px-4 py-2 rounded-xl text-xs font-semibold ${
                tab === "overview" ? "bg-pink-600 text-white" : "bg-zinc-900 text-zinc-400"
              }`}
            >
              About & Persona
            </button>
            <button
              onClick={() => setTab("photos")}
              className={`px-4 py-2 rounded-xl text-xs font-semibold ${
                tab === "photos" ? "bg-pink-600 text-white" : "bg-zinc-900 text-zinc-400"
              }`}
            >
              Profile Photos ({photos.length + 1})
            </button>
            <button
              onClick={() => setTab("videos")}
              className={`px-4 py-2 rounded-xl text-xs font-semibold ${
                tab === "videos" ? "bg-pink-600 text-white" : "bg-zinc-900 text-zinc-400"
              }`}
            >
              Profile Videos ({videos.length})
            </button>
          </div>

          {tab === "overview" && (
            <div className="bg-zinc-950 border border-white/10 rounded-3xl p-6 space-y-4">
              <div>
                <h3 className="text-xs uppercase tracking-wider text-zinc-400 mb-1">
                  Background & Story
                </h3>
                <p className="text-sm text-zinc-200 leading-relaxed">{character.background}</p>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-zinc-900/70 border border-white/5">
                  <div className="text-xs text-zinc-400">Personality</div>
                  <div className="text-sm font-semibold mt-1">{character.personality}</div>
                </div>
                <div className="p-4 rounded-2xl bg-zinc-900/70 border border-white/5">
                  <div className="text-xs text-zinc-400">Figure & Look</div>
                  <div className="text-sm font-semibold mt-1">{character.figure}</div>
                </div>
              </div>
              <div className="p-4 rounded-2xl bg-pink-950/20 border border-pink-500/30">
                <div className="text-xs text-pink-300 font-semibold">Favorite Fantasy & Kink</div>
                <div className="text-sm text-zinc-200 mt-1">{character.kink}</div>
              </div>
              <div className="flex flex-wrap gap-2 pt-2">
                {character.tags.map((t) => (
                  <button
                    key={t}
                    onClick={() => onTag(t)}
                    className="px-3 py-1 rounded-full text-xs bg-zinc-900 hover:bg-pink-600/20 border border-white/10 text-zinc-300"
                  >
                    #{t}
                  </button>
                ))}
              </div>
            </div>
          )}

          {tab === "photos" && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="rounded-2xl overflow-hidden border border-white/10 bg-zinc-950">
                <img
                  src={character.avatar}
                  alt={character.name}
                  className="w-full aspect-[3/4] object-cover"
                />
                <div className="p-2.5 text-[11px] text-zinc-400">Default Profile Portrait</div>
              </div>
              {photos.map((item) => (
                <div
                  key={item.id}
                  className="rounded-2xl overflow-hidden border border-pink-500/30 bg-zinc-950"
                >
                  <img
                    src={item.url}
                    alt={item.prompt || character.name}
                    className="w-full aspect-[3/4] object-cover"
                  />
                  <div className="p-2.5 text-[11px] text-zinc-300 truncate">
                    {item.prompt || item.type}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "videos" && (
            <div>
              {videos.length === 0 ? (
                <div className="p-8 rounded-3xl bg-zinc-950 border border-white/10 text-center space-y-3">
                  <p className="text-sm text-zinc-400">
                    No motion videos generated for {character.name} yet.
                  </p>
                  <button
                    onClick={() => {
                      setStyleType("video");
                      handleGenerateIntoProfile();
                    }}
                    className="px-5 py-2.5 rounded-xl bg-pink-600 text-xs font-semibold"
                  >
                    Generate First Profile Video (Free)
                  </button>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-4">
                  {videos.map((v) => {
                    const frameUrl =
                      v.frames && v.frames.length > 0
                        ? v.frames[activeFrameIdx % v.frames.length]
                        : v.url;
                    return (
                      <div
                        key={v.id}
                        className="rounded-2xl overflow-hidden border border-fuchsia-500/40 bg-zinc-950"
                      >
                        <div className="relative aspect-[9/12] bg-black">
                          <img
                            src={frameUrl}
                            alt={v.prompt || character.name}
                            className="w-full h-full object-cover transition-all duration-500"
                          />
                          <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold bg-fuchsia-600 text-white">
                            ▶ LIVE MOTION LOOP
                          </span>
                        </div>
                        <div className="p-3 text-xs text-zinc-300">{v.prompt || "Motion Clip"}</div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
