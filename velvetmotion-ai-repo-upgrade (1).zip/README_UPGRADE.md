# VelvetMotion AI — AAA Candy.ai-Style Upgrade & CI/Build Fix Package

## What Was Fixed & Upgraded
1. **Fixed Vercel & GitHub Actions Build Failures**:
   - Fixed the `DiscoverSwipe` TypeScript prop mismatch (`onHome`/`onMatch` + `onBack`/`onChat` support).
   - Fixed `.github/workflows/validate.yml` to run `npm ci`, `npm test`, `npm run lint`, and `npm run build`.
   - Removed the 4 failing starter workflows (`deno.yml`, `webpack.yml`, `npm-publish.yml`, `npm-publish-github-packages.yml`).
2. **Fixed `firestore.rules` Syntax Error & Hardened Security**:
   - Added the missing `||` operator on line 161 of `firestore.rules`.
   - Removed the 21 excessive Google Workspace OAuth scopes (`gmail.*`, `drive.*`, `chat.*`, `meetings.*`) and failing `test/connection` probe from `lib/firebase.ts`.
3. **100% Free Unlimited Mode (`lib/storage.ts`)**:
   - Set all `GEN_COST` values (`portrait`, `lingerie`, `nude`, `explicit`, `video`) to `0` coins.
   - Added `getCharacterGallery(characterId)` so every generated photo and video saves directly into that character's profile as well as the global gallery.
4. **Dynamic AI Chat, Profile Photo/Video Generation, and Two-Way Tinder Roleplay**:
   - Upgraded `app/api/chat/route.ts`, `app/api/generate-image/route.ts`, and `app/api/generate-video/route.ts` with free keyless Pollinations AI + rich persona engine fallback.
   - Upgraded `components/DiscoverSwipe.tsx` with a full Guy/Girl/Custom player persona builder and Reverse Tinder Roleplay mode.

## Quick Apply Commands
```bash
# 1. Remove leftover starter workflows and duplicate lockfile/rules
rm -f bun.lock DRAFT_firestore.rules netlify.toml \
  .github/workflows/deno.yml \
  .github/workflows/webpack.yml \
  .github/workflows/npm-publish.yml \
  .github/workflows/npm-publish-github-packages.yml

# 2. Regenerate package-lock.json cleanly and verify build
npm install
npm test
npm run build
```
